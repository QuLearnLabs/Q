# Qiskit 1.x Compatibility Fixer Tool

This standalone tool automatically fixes deprecated Qiskit code patterns to make them compatible with Qiskit 1.x.

## Quick Setup

```bash
python3 qiskit_tools.py --setup
```

## What This Tool Fixes

1. **Aer Import Fix**: Updates from `from qiskit import Aer` to `from qiskit_aer import Aer` 
2. **Execute Pattern Fix**: Replaces deprecated `execute()` with the modern `transpile()` + `run()` pattern

## Usage

```bash
# Fix a specific file
python3 qiskit_tools.py -f path/to/file.py

# Monitor clipboard for Qiskit code
python3 qiskit_tools.py --watch

# Scan all Python files in current directory
python3 qiskit_tools.py --once

# Monitor and automatically fix files as you edit
python3 qiskit_tools.py --watcher
```

## Dependencies

This tool requires:
- Python 3.6+
- qiskit>=1.0.0
- qiskit-aer>=0.12.0 
- matplotlib>=3.7.0
- pyperclip>=1.8.2 (for clipboard monitoring)

## License

This tool is part of the Q extension by QuLearnLabs, licensed under Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.

Version 1.0.0
